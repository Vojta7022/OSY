#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

typedef struct Node {
    int x;
    char *word;            
    struct Node *next;
} Node;

static Node *head = NULL, *tail = NULL;
static pthread_mutex_t qmtx = PTHREAD_MUTEX_INITIALIZER; 
static pthread_cond_t  qcv  = PTHREAD_COND_INITIALIZER;   
static pthread_mutex_t outmtx = PTHREAD_MUTEX_INITIALIZER; 

static int done = 0;           
static int invalid_input = 0;  
static int N = 1;              

static void enqueue(Node *n) {
    if (tail) tail->next = n; else head = n;
    tail = n; n->next = NULL;
}
static Node *dequeue(void) {
    Node *n = head;
    if (n) {
        head = n->next;
        if (!head) tail = NULL;
    }
    return n;
}

static void *producer(void *arg) {
    (void)arg;
    int x, ret;
    char *text;
    while ((ret = scanf("%d %ms", &x, &text)) == 2) {
        if (x < 0) {               
            free(text);
            invalid_input = 1;
            break;
        }
        Node *n = (Node*)malloc(sizeof(Node));
        n->x = x; n->word = text; n->next = NULL;
        pthread_mutex_lock(&qmtx);
        enqueue(n);
        pthread_cond_signal(&qcv);
        pthread_mutex_unlock(&qmtx);
    }
    pthread_mutex_lock(&qmtx);
    done = 1;
    if (ret != EOF) invalid_input = 1;
    for (int i = 0; i < N; ++i) pthread_cond_signal(&qcv);
    pthread_mutex_unlock(&qmtx);
    return NULL;
}

static void *consumer(void *arg) {
    int id = *(int*)arg;
    for (;;) {
        pthread_mutex_lock(&qmtx);
        while (!head && !done) pthread_cond_wait(&qcv, &qmtx);
        Node *n = dequeue();
        int should_exit = (!n && done);
        pthread_mutex_unlock(&qmtx);
        if (should_exit) break;
        if (!n) continue; 

        pthread_mutex_lock(&outmtx);
        printf("Thread %d:", id);
        for (int i = 0; i < n->x; ++i) printf(" %s", n->word);
        printf("\n");
        fflush(stdout);
        pthread_mutex_unlock(&outmtx);

        free(n->word);
        free(n);
    }
    return NULL;
}

int main(int argc, char **argv) {
    long tmpN = 1;
    if (argc >= 2) {
        char *end = NULL;
        tmpN = strtol(argv[1], &end, 10);
        if (!end || *end || tmpN < 1) return 1;
    }
    long cpus = sysconf(_SC_NPROCESSORS_ONLN);
    if (tmpN < 1 || tmpN > cpus) return 1;
    N = (int)tmpN;

    pthread_t prod;
    pthread_t *cons = (pthread_t*)malloc(sizeof(pthread_t) * N);
    int *ids = (int*)malloc(sizeof(int) * N);

    for (int i = 0; i < N; ++i) {
        ids[i] = i + 1;
        pthread_create(&cons[i], NULL, consumer, &ids[i]);
    }
    pthread_create(&prod, NULL, producer, NULL);

    pthread_join(prod, NULL);
    for (int i = 0; i < N; ++i) pthread_join(cons[i], NULL);

    free(ids);
    free(cons);

    while (head) {
        Node *n = dequeue();
        free(n->word);
        free(n);
    }
    pthread_mutex_destroy(&qmtx);
    pthread_mutex_destroy(&outmtx);
    pthread_cond_destroy(&qcv);

    return invalid_input ? 1 : 0;
}
