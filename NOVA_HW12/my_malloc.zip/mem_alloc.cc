#include "mem_alloc.h"
#include <stdio.h>

/*
 * Template for 11malloc. If you want to implement it in C++, rename
 * this file to mem_alloc.cc.
 */

/* Simple block header stored before each user allocation.
 * Size is 16 bytes on 32-bit: 4 (size) + 4 (next) + 4 (free) + 4 (pad).
 * -> overhead for malloc(16) is exactly 100%.
 */
typedef struct block_header
{
    unsigned long size;        /* size of user data in bytes */
    struct block_header *next; /* next block in our list      */
    int free;                  /* 1 = free, 0 = allocated     */
    int pad;                   /* padding to make header 16 B */
} block_header_t;

/* First and last block in our simple singly linked list */
static block_header_t *g_head = 0;
static block_header_t *g_tail = 0;

/* Remember where our heap starts (first call to nbrk(0)) */
static void *g_heap_start = 0;

/* Alignment requirement for user pointers */
#define ALIGNMENT 8UL

static inline void *nbrk(void *address);

#ifdef NOVA

/**********************************/
/* nbrk() implementation for NOVA */
/**********************************/

static inline unsigned syscall2(unsigned w0, unsigned w1)
{
    asm volatile("   mov %%esp, %%ecx    ;"
                 "   mov $1f, %%edx      ;"
                 "   sysenter            ;"
                 "1:                     ;"
                 : "+a"(w0)
                 : "S"(w1)
                 : "ecx", "edx", "memory");
    return w0;
}

static void *nbrk(void *address)
{
    return (void *)syscall2(3, (unsigned)address);
}
#else

/***********************************/
/* nbrk() implementation for Linux */
/***********************************/

#include <unistd.h>

static void *nbrk(void *address)
{
    void *current_brk = sbrk(0);
    if (address != NULL)
    {
        int ret = brk(address);
        if (ret == -1)
            return NULL;
    }
    return current_brk;
}

#endif

void *my_malloc(unsigned long size)
{
    if (size == 0)
        return 0;

    /* Initialize heap start on first use (for simple range checking) */
    if (!g_heap_start)
    {
        g_heap_start = nbrk(0);
        if (!g_heap_start)
            return 0;
    }

    /* Align requested size to 8 bytes */
    unsigned long aligned = (size + (ALIGNMENT - 1)) & ~(ALIGNMENT - 1);

    block_header_t *block = 0;
    block_header_t *cur;

    /* 1) First-fit: try to reuse an existing free block */
    for (cur = g_head; cur != 0; cur = cur->next)
    {
        if (cur->free && cur->size >= aligned)
        {
            block = cur;
            break;
        }
    }

    if (!block)
    {
        /* 2) No suitable free block -> ask kernel for more heap space */
        unsigned long total = sizeof(block_header_t) + aligned;

        void *old_brk = nbrk(0);
        if (!old_brk)
            return 0;

        void *new_brk = (void *)((char *)old_brk + total);
        void *ret = nbrk(new_brk);
        if (!ret)
            return 0; /* allocation failed */

        block = (block_header_t *)ret;
        block->size = aligned;
        block->free = 0;
        block->next = 0;
        block->pad = 0;

        if (g_tail)
            g_tail->next = block;
        else
            g_head = block;

        g_tail = block;
    }
    else
    {
        /* Reuse existing free block as a whole (no splitting) */
        block->free = 0;
    }

    /* Return pointer to user data (immediately after the header) */
    return (void *)((char *)block + sizeof(block_header_t));
}

int my_free(void *address)
{
    if (!address)
        return 1; /* error: NULL pointer */

    /* Compute pointer to our block header */
    block_header_t *block =
        (block_header_t *)((char *)address - sizeof(block_header_t));

    /* Simple range check: pointer must be inside our heap area */
    void *current_brk = nbrk(0);
    if (!g_heap_start || !current_brk)
        return 2; /* allocator not initialized correctly */

    if ((void *)block < g_heap_start || (void *)block >= current_brk)
        return 3; /* pointer is not from our heap (not from my_malloc) */

    /* Detect double free */
    if (block->free)
        return 4; /* error: double free */

    /* Mark block as free so it can be reused later */
    block->free = 1;

    /* No coalescing: we keep blocks as-is, only reuse them by first-fit */
    return 0;
}
